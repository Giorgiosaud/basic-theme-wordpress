<?php
/* @var $this N2Layout */

$this->renderFragmentBlock('nextend_content');
