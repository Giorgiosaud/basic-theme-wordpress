<?php
$sliderManager = new N2SmartSliderManager($sliderid);
$sliderManager->setUsage($usage);
echo $sliderManager->render(true);

