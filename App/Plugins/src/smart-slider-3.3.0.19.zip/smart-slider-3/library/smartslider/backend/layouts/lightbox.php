<?php
require(N2Base::getApplication('system')->getApplicationType('backend')->path . '/layouts/lightbox.php');