<?php
$slider = $_class->_renderSlider($sliderId, array(
    'slidesData' => $slidesData
));
include(dirname(__FILE__) . '/_preview.php');


if (!empty($slidesData)) {
    $slideId = key($slidesData);
    if ($slideId > 0) {
        ?>
        <script type="text/javascript">
            n2ss.ready(<?php echo $sliderId; ?>, function (slider) {
                slider.visible(function () {
                    slider.slideToID(<?php echo key($slidesData); ?>);
                });
            });
        </script>
    <?php
    }
}
