<?php
/* @var $this N2Layout */
?>
    <div id="n2-admin" class="n2 n2-border-radius">
        <?php
        $this->renderFragmentBlock('nextend_content');
        ?>
    </div>
<?php
N2JS::addInline("new NextendExpertMode('smartslider', " . N2SSPRO . ");");