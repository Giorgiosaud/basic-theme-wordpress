<?php
/* @var $this N2Layout */
?>
<div id="<?php echo $lightboxId; ?>">
    <?php
    $this->renderFragmentBlock('nextend_sidebar');
    ?>
</div>