<?php
echo N2SmartsliderSlidesModel::box($slide, $slider, $this->widget, $this->appType);
