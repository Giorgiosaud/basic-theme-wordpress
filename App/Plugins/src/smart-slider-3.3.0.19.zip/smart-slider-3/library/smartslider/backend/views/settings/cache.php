<h2>Cache</h2>
<?php
$buttons = array();

$buttons[] = array(
    'title'       => n2_('Clear sliders'),
    'htmlOptions' => array(
        'href' => $this->appType->router->createUrl(array(
                'settings/cache',
                array(
                    'refreshcache' => 1
                )
            ))
    ),
    'iconclass'   => 'nii nii-24x42 nii-global-action-icon nii-refresh'
);

$buttons[] = array(
    'title'       => n2_('Clear generators'),
    'htmlOptions' => array(
        'href' => $this->appType->router->createUrl(array(
                'settings/cache',
                array(
                    'refreshcache' => 2
                )
            ))
    ),
    'iconclass'   => 'nii nii-24x42 nii-global-action-icon nii-refresh'
);