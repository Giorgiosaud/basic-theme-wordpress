<?php

$this->widget->init('topbar', array(
    "actions" => array(
        N2Html::tag('a', array(
            'href'  => $this->appType->router->createUrl(array('sliders/index')),
            'class' => 'n2-button n2-button-red n2-button-big n2-h4 n2-b n2-uc'
        ), n2_('Cancel')),
        N2Html::tag('a', array(
            'href'    => '#',
            'class'   => 'n2-button n2-button-green n2-button-big n2-h4 n2-b n2-uc',
            'onclick' => 'return NextendForm.submit("#smartslider-form");'
        ), n2_('Import'))
    )
));
?>

<form id="smartslider-form" enctype="multipart/form-data" action="" method="post">
    <?php
    $_class->renderImportByUploadForm();
    ?>
    <input name="save" value="1" type="hidden"/>
</form>

<div class="n2-form ">
    <div class="n2-form-tab ">
        <div class="n2-h2 n2-content-box-title-bg"><?php n2_e('Instructions'); ?></div>

        <div class="n2-description">
            <p><?php n2_e('You can upload the files which exported by Smart Slider 3.'); ?></p>

            <p><?php printf(n2_('Your server has an upload file limit at %s, so if you have bigger export file, please use the <a href="%s">alternate method</a>.'), @ini_get('post_max_size'), $this->appType->router->createUrl(array('sliders/importFromServer'))); ?></p>
        </div>
    </div>
</div>
<?php N2SS3::showBeacon('Import slider'); ?>