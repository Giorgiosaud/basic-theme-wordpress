<div class="n2-form-tab ">
    <div class="n2-h2 n2-content-box-title-bg"><?php n2_e('Limited access'); ?></div>

    <div class="n2-description">
        <p><?php n2_e('Access to this resource not allowed!'); ?></p>
    </div>
</div>