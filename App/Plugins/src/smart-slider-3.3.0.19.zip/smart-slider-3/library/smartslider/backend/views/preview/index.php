<?php
$slider = $_class->_renderSlider($sliderId, array('sliderData' => $sliderData));
include(dirname(__FILE__) . '/_preview.php');