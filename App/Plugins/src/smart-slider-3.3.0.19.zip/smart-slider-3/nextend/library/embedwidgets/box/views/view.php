<?php echo N2Html::openTag('div', $attributes); ?>
<?php if ($image[0] == '<'): ?>
    <?php echo $image; ?>
<?php else: ?>
    <img src="<?php echo N2ImageHelper::fixed($image); ?>"/>
<?php endif; ?>


<?php
if ($lt) {
    echo N2Html::tag('div', $ltAttributes, $lt);
}
if ($rt) {
    echo N2Html::tag('div', $rtAttributes, $rt);
}
if ($lb) {
    echo N2Html::tag('div', $lbAttributes, $lb);
}
if ($rb) {
    echo N2Html::tag('div', $rbAttributes, $rb);
}
if ($center) {
    echo N2Html::tag('div', $centerAttributes, $center);
}
if ($overlay) {
    echo N2Html::tag('div', array(
        'class' => 'n2-box-overlay n2-on-hover'
    ), $rb);
}
?>

<?php
if ($firstCol):
    ?>
    <div class="n2-box-placeholder">
        <?php echo $placeholderContent; ?>
        <?php
        if ($secondCol):
            ?>
            <table>
                <tr>
                    <td class="n2-box-button"><?php echo $firstCol; ?></td>
                    <td class="n2-box-button"><?php echo $secondCol; ?></td>
                </tr>
            </table>
        <?php
        else:
            ?>
            <table>
                <tr>
                    <td class="n2-box-button"><?php echo $firstCol; ?></td>
                </tr>
            </table>
        <?php
        endif;
        ?>
    </div>
<?php
endif;
?>
</div>