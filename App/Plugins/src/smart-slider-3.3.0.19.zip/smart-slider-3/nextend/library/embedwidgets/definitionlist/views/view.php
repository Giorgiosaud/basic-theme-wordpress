<?php
echo N2Html::openTag('dl', array('class' => $class . " n2-h3"));

if (isset($dl) && count($dl)) {

    foreach ($dl as $dlRow) {

        //BEGIN <DT>
        if (!isset($dlRow['options'])) $dlRow['options'] = array();
        echo N2Html::openTag('dt', $dlRow['options'] + array('class' => $dlRow['class']));
        if (isset($dlRow["linkOptions"])) {
            echo N2Html::tag('a', (isset($dlRow['linkOptions']) ? $dlRow['linkOptions'] : array()), $dlRow['title']);
        } elseif (isset($dlRow["link"])) {
            echo N2Html::tag('a', array('href' => $dlRow['link']), $dlRow['title']);
        } else {
            echo N2Html::tag('div', array(), $dlRow['title']);
        }

        if (!empty($dlRow['actions'])) {
            echo N2Html::tag('span', array('class' => 'n2-actions'), $dlRow['actions']);
        }

        if (!empty($dlRow['after'])) echo $dlRow['after'];
        echo N2Html::closeTag('dt');

        echo N2Html::openTag('dd', array('class' => $dlRow['class']));

        if (!empty($dlRow["preUl"])) {
            echo $dlRow["preUl"];
        }

        /**
         * @see Listn
         */
        if (!empty($dlRow["ul"])) {
            echo $this->widget->init('listn', array('ul' => $dlRow["ul"]));
        }
        echo N2Html::closeTag('dd');
    }

}
echo N2Html::closeTag('dl');
?>