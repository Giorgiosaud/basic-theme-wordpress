<?php
/* @var $this N2Layout */
?>
<div id="<?php echo $lightboxId; ?>" class="n2 n2-lightbox-container n2-lightbox-no-sidebar">
    <div class="n2-lightbox n2-border-radius">

        <div class="n2-table n2-table-fixed n2-content">
            <div class="n2-tr">
                <div class="n2-td n2-content-base-bg">
                    <!-- Begin Content -->
                    <div class="n2-table n2-table-fixed">
                        <div class="n2-tr">
                            <div class="n2-td n2-sidebar">
                                <div class="n2-blue-logo-bg n2-logo n2-border-radius-tl n2-lightbox-heading n2-h2">
                                    <?php
                                    echo $logo;
                                    ?>
                                </div>
                            </div>
                            <div class="n2-td">
                                <?php
                                $this->renderFragmentBlock('nextend_content_top_bar');
                                ?>
                            </div>
                        </div>
                    </div>
                    <div class="n2-content-area n2-border-radius-br">
                        <?php
                        $this->renderFragmentBlock('nextend_content');
                        ?>
                    </div>
                    <!-- End Content -->
                </div>
            </div>
        </div>
    </div>
</div>