<?php
/* @var $this N2Layout */
?>
    <style type="text/css">
        <?php N2Platform::adminHideCSS(); ?>
    </style>
    <div id="n2-admin" class="n2 n2-lightbox n2-sidebar-hidden n2-border-radius">

        <?php
        /**
         * @var $widget Nav
         */
        $logoUrl = N2Base::getApplication('system')->getLogo();
        $cmd     = N2Request::getVar("nextendcontroller", "dashboard");

        ?>

        <div class="n2-table n2-table-fixed n2-content">
            <div class="n2-tr">
                <div class="n2-td n2-content-base-bg">
                    <!-- Begin Content -->
                    <div class="n2-content-area n2-border-radius-br">
                        <?php
                        $this->renderFragmentBlock('nextend_content');
                        ?>
                    </div>
                    <!-- End Content -->
                </div>
            </div>
        </div>

    </div>
<?php

N2Message::show();